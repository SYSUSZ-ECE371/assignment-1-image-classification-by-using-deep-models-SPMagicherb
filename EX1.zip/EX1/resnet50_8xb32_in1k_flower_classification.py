_base_ = 'C:/Users/SPherb/mmpretrain/configs/resnet/resnet50_8xb32_in1k.py'
# >>>>>>>>>>>>>>> 在这里重载模型相关配置 >>>>>>>>>>>>>>>>>>>
model = dict(
    backbone=dict(
        frozen_stages=2,
        init_cfg=dict(
            type='Pretrained',
            checkpoint='C:/Users/SPherb/.cache/torch/hub/checkpoints/resnet50_8xb32_in1k_20210831-ea4938fc.pth',
            prefix='backbone',
        )),
    head=dict(num_classes=5),
)
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

# >>>>>>>>>>>>>>> 在这里重载数据配置 >>>>>>>>>>>>>>>>>>>
train_dataloader = dict(
    # 训练数据集配置
    dataset=dict(
        type='ImageNet',
        data_root = 'D:/Python_Program/neural_network/data',
        ann_file='D:/Python_Program/neural_network/data/meta/train.txt',
        data_prefix='train',

    )
)

val_dataloader = dict(
    # 验证数据集配置
    dataset=dict(
        type='ImageNet',
        data_root = 'D:/Python_Program/neural_network/data',
        ann_file='D:/Python_Program/neural_network/data/meta/val.txt',
        data_prefix='val',

    )
)
val_evaluator = dict(type='Accuracy', topk=1)

# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

# >>>>>>>>>>>>>>> 在这里重载训练策略设置 >>>>>>>>>>>>>>>>>>>
# 优化器超参数
optim_wrapper = dict(
    optimizer=dict(type='SGD', lr=0.01, momentum=0.9, weight_decay=0.0001))
# 学习率策略
param_scheduler = dict(
    type='MultiStepLR', by_epoch=True, milestones=[15], gamma=0.1)
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<